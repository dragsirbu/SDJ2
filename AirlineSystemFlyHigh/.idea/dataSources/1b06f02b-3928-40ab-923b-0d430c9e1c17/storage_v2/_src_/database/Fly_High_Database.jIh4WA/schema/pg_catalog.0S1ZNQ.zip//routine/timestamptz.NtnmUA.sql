CREATE FUNCTION timestamptz(date, time without time zone)
  RETURNS timestamp with time zone
STABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select cast(($1 + $2) as timestamp with time zone)
$$;

